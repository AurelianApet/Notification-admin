/*--------------------------------------------- open popbox (add contact btn) ------------------------------------*/
$(document).ready(function(){
  $(".add-contact").click(function(){
    $("#myOverlay").css("display", "block");
  });
   $(".overlay--closebtn").click(function(){
    $("#myOverlay").css("display", "none");
  });
});

 
/*--------------------------------------------- active menu ------------------------------------*/ 
 $(document).ready(function () {
    $('.mwt__navbar--menu a').on('click', function (e) {
        e.preventDefault();
        
        $('.mwt__navbar--menu a').each(function () {
            $(this).removeClass('active-menu');
        })
        $(this).addClass('active-menu');
      
        var target = this.hash,
            menu = target;
        $target = $(target);
    });
});



 
 
 
 
 
 
 
